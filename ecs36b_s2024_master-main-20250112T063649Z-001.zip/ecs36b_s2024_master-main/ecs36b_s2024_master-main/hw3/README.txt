Soren Keck 921 172 910 sdkeck@ucdavis.edu
Kevali Shah 920 726 532 ktshah@ucdavis.edu
Ethan Thurston 922 288 311 ejthurston@ucdavis.edu
