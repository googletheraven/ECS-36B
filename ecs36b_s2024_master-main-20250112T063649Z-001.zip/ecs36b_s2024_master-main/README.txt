
This directory contains all the code related to the lectures during
the Spring quarters. For most of the programming assignments, the
solutions should be either related or derivable from some code
segments (but you need to identify where they are) here as well.

The final project should be developed as an extension, in the form of
some new functionality, from this master directory.
